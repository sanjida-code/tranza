
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Catergory-Corbel</title>	
	<!-- bootstrap link  -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

	<!-- icon-link   -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<!-- slick css  -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" integrity="sha512-yHknP1/AwR+yx26cB1y0cjvQUMvEa2PFzt1c9LlS4pRQ5NOTZFWbhBig+X9G9eYW/8m0/4OXNx8pxJ6z57x0dw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<!-- css link  -->
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="category.css">
</head>
<body>

	<header class="content">
		<section>
			<ul class="nav justify-content-end">
				<li class="nav-item"><a class="nav-link text-dark" href="#"><b>Welcome, Jordan</b></a></li>
				<li class="nav-item"><a class="nav-link text-dark" href="#">My Account <i class="fa fa-caret-down"></i></a></li>
				<li class="nav-item">
					<a class="nav-link text-dark" href="#">My List</a>
				</li>
			</ul>
		</section>
		<section class ="display-flex"> 
			<!-- logo  -->
			<a href="index.php"><img class= "logo" src="images/Logo.png" alt="" srcset=""></a>
			<!-- search-bar  -->
			<div class="search-bar">
				<span class = "all">All <i class="fa fa-caret-down"></i></span>
				<input class = "search-input"  type="text" placeholder="Search"> <i class="fa fa-search"></i>
			</div>
			<!-- Questions and Phone  -->
			<div class="call">
				<a class="nav-link " href="#">Questions?<br>Call 781.843.6666</a>
			</div>
			
			<div class="cart"> <span id = "cart">Cart</span>| 8 Items/$1,042.00 				
			</div>
			<div class ="shopping-card">
			    <img src="images/shopping-card.png" alt="" srcset="">
			</div>
		</section>
<!-- navbar  -->
		<section>
			<nav>
				<ul>
					<li>
						<a  href="index.php"><img src="images/home-icon.png" alt="" srcset=""></a>
						<div class = "menu-icon">
						</div>
					</li>
					<span>|</span>
					<li>
						<div class="dropdown1">
							<button class="dropbtn">MOULDINGS & BOARDS </button>
						<div>
							<img id ="down-arrow" src="images/down-icon.png" alt="" srcset="">
						</div>
							<div class="dropdown-content">  
								<div class="row">
									<div class="column">
									<a href="#">Link 1</a>
									<a href="#">Link 2</a>
									<a href="#">Link 3</a>
									</div>
									<div class="column">
									<a href="#">Link 1</a>
									<a href="#">Link 2</a>
									<a href="#">Link 3</a>
									</div>       
								</div>
							</div>
						</div> 
					</li>
					<span>|</span>
					<li>
						<div class="dropdown1">
							<button class="dropbtn">STAIR PARTS </button>
						<div>
						<img src="images/down-icon.png" alt="" srcset="">
						</div>
						<div class="dropdown-content1">  
							<div class="row">
								<div class="column">
								<a href="#">Link 1</a>
								<a href="#">Link 2</a>
								<a href="#">Link 3</a>
								</div>
							</div>
							</div>
						</div> 
					</li>
					<span>|</span>
					<li>
					<div class="dropdown1">
							<button class="dropbtn">ACCENTS </button>
						<div>
							<img  src="images/down-icon.png" alt="" srcset="">
						</div>
							<div class="dropdown-content2">  
								<div class="row">
									<div class="column">
									<a href="#">Link 1</a>
									<a href="#">Link 2</a>
									<a href="#">Link 3</a>
									</div>
									<div class="column">
									<a href="#">Link 1</a>
									<a href="#">Link 2</a>
									<a href="#">Link 3</a>
									</div>       
								</div>
							</div>
						</div> 
					</li>
					<span>|</span>
					<li>
						<a  href="#">CUSTOM MOULDINGS</a>
						<div class = "menu-icon">
						</div>
					</li>
					<span>|</span>
					<li >
						<a  href="#">CONTACT</a>
						<div class = "menu-icon">
						</div>
					</li>
				</ul>
			</nav>
		</section>
	</header>


<!-- small header -->
	<section class="content">
		<div class="small-header">
		<a href="">Home/</a>
		<a href="">Accents/</a>
		<a href="">Corbels</a>
		</div>
	</section>
	<main>
<!-- side-menu  -->
	<section class="content">
		<div class = "row">

			<div class="col-3">
				<div class  = " side-menu ">
					<a href=""><b>MOULDINGS & BOARDS</b></a>
				</div>
				<div class  = " side-menu ">
					<a href=""><b>STAIR PARTS</b></a>
				</div>
				<div class  = " side-menu ">
					<a href=""><b>ACCENTS</b></a>
					
				</div>
				<div class="items-three">
					<ul>
						<li> <img src="images/arrow-side.png" alt="" srcset=""> <a href="">Crobels</a></li>
						<li> <img src="images/arrow-side.png" alt="" srcset=""> <a href="">Brackets</a></li>
						<li> <img src="images/arrow-side.png" alt="" srcset=""> <a href="">Medalions</a></li>
					</ul>
				</div>
				<div class  = " side-menu ">
					<a href=""><b>CUSTOM MOULDINGS</b></a>
				</div>

				<DIV class="free-shopping py-5"> 
					<h4>FREE SHOPPING <br> ON ALL ORDERS</h4>
					<h1>OVER <span class = "dollar175 align-top">$</span>175</h1>
				</DIV>
				<img src="images/category-corbels.png" alt="" srcset="">
				<h4>Inspiration Gallery</h4>
			</div>
			<div class="col-9">
		<!-- product view card  -->
				<section>
					<div class = " ">
						<h2><b>Corbels</b> </h2>
					</div>
						<img src="images/yollow-line.png" alt="" srcset="">
				</section>
				
		<!-- row 1  -->
				<section>
					<div class="row py-4">
						<!-- row 1 col 1  -->
						<div class="col">
							<div class="card">
								<img src="images/first-col-image1.png" alt=" ">
								<h3><b>Architrave 5010</b></h3>
								<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
								<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
								<p><button><span class = "plus">+</span>Select Option</button></p>
								<div class = "new-sale">
									<img src="images/new(1).png" alt="" srcset="">
								</div>
							</div>
						</div>
						<!-- row 1 col 2  -->
						<div class="col">
							<div class="card">
								<img src="images/first-col-img2.png" alt=" ">
								<h3><b>Architrave 5010</b></h3>
								<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
								<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
								<p><button><span class = "plus">+</span>Select Option</button></p>
							</div>
						</div>
						<!-- row 1 col 3  -->		
						<div class="col">
							<div class="card">
								<img src="images/first-col-img3.png" alt=" ">
								<h3><b>Architrave 5010</b></h3>
								<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
								<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
								<p><button><span class = "plus">+</span>Select Option</button></p>
								<div class = "new-sale">
									<img src="images/sale(1).png" alt="" srcset="">
								</div>
							</div>
						</div>
						<!-- row 1 col 4  -->
						<div class="col">
							<div class="card">
								<img src="images/first-col-img4.png" alt=" ">
								<h3><b>Architrave 5010</b></h3>
								<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
								<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
								<p><button><span class = "plus">+</span>Select Option</button></p>
							</div>
						</div>
					</div>
				</section>
		<!-- row 2  -->	
				<section>
					<div class="row py-4">
					<!-- row 2 col 1  -->
						<div class="col">
							<div class="card">
								<img src="images/second-col-img1.png" alt=" ">
								<h3><b>Architrave 5010</b></h3>
								<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
								<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
								<p><button><span class = "plus">+</span>Select Option</button></p>
								<div class="new-sale">
									<img src="images/new(1).png" alt="" srcset="">
								</div>
							</div>
						</div>
						<!-- row 2 col 2  -->
						<div class="col">
							<div class="card card-height">
								<img src="images/second-col-img2.png" alt=" ">
								<h3><b>Architrave 5010</b></h3>
								<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
								<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
								<p><button><span class = "plus">+</span>Select Option</button></p>
							</div>
						</div>
						<!-- row 2 col 3  -->
						<div class="col">
							<div class="card">
								<img src="images/second-col-img3.png" alt=" ">
								<h3><b>Architrave 5010</b></h3>
								<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
								<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
								<p><button><span class = "plus">+</span>Select Option</button></p>
								<div class="new-sale">
									<img src="images/sale(1).png" alt="" srcset="">	
								</div>
							</div>
						</div>
						<!-- row 2 col 4  -->
						<div class="col">
							<div class="card card-height">
								<img src="images/second-col-img4.png" alt=" ">
								<h3><b>Architrave 5010</b></h3>
								<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
								<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
								<p><button><span class = "plus">+</span>Select Option</button></p>
							</div>
						</div>
					</div>
				</section>
		<!-- row 3  -->
				<section>
					<div class="row py-4">
						<!-- row 3 col 1  -->
						<div class="col">
							<div class="card">
								<img src="images/third-col-img1.png" alt=" ">
								<h3><b>Architrave 5010</b></h3>
								<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
								<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
								<p><button><span class = "plus">+</span>Select Option</button></p>
								<div class="new-sale">
									<img src="images/new(1).png" alt="" srcset="">
								</div>
							</div>
						</div>
							<!-- row 3 col 2  -->
						<div class="col">
							<div class="card">
								<img src="images/third-col-img2.png" alt=" ">
								<h3><b>Architrave 5010</b></h3>
								<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
								<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
								<p><button><span class = "plus">+</span>Select Option</button></p>
							</div>
						</div>
							<!-- row 3 col 3  -->
						<div class="col">
							<div class="card row3-col3">
								<img src="images/third-col-img3.png" alt=" ">
								<h3><b>Architrave 5010</b></h3>
								<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
								<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
								<p><button><span class = "plus">+</span>Select Option</button></p>
								<div class="new-sale">
									<img src="images/sale(1).png" alt="" srcset="">
								</div>
							</div>
						</div>
							<!-- row 3 col 4  -->
						<div class="col">
							<div class="card">
								<img src="images/third-col-img4.png" alt=" ">
								<h3><b>Architrave 5010</b></h3>
								<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
								<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
								<p><button><span class = "plus">+</span>Select Option</button></p>
							</div>
						</div>
					</div>
				</section>
			</div>
		</div>
	</section>
	</main>
	<br>
	<br>
<!-- FOOTER  -->
	<footer>
	<div class="content">
		<div class="row footer-section1">
			<div class="col">
				<img src="images/Logo.png" alt="" srcset="">
			</div>
			<div class="col">
				<div class="row">
					<div class="col-1">
						<img src="images/call-icon.png" alt="" srcset="">
					</div>
					<div class="col-9">				
						<a class="nav-link pt-0 phone" href="#">781.843.6666</a>
						<a class="nav-link pt-0 pb-5" href="email">info@ndmoulding.com</a>
					</div>
				</div>
			</div>
			<div class="col">
				<div class="row">
					<div class="col-2">
						<img src="images/home-icon.png" alt="" srcset="">
					</div>
					<div class="col-10">
						<h5>236 Wood Rd.</h5>
						<h6>Braintree, MA 02184</h6>
					</div>
				</div>
			</div>
			<div class="col">
				<div class="row">
					<div class="col-2">
						<img src="images/home-icon.png" alt="" srcset="">
					</div>
					<div class="col-10">
						<h5>10 industrial Pkwy</h5>
						<h6>Woburn, MA 01801</h6>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="row">
					<div class="col-2">
						<img src="images/clock-icon.png" alt="" srcset="">
					</div>
					<div class="col-10">
						<h5>Mon - Fri, 7 a.m. -6 p.m.</h5>
						<h5>Sat, 7 a.m. -2 p.m.</h5>
					</div>
				</div>
			</div>
		</div>
	</div>
		<div id = footer-section2>
			<p class="content"><b>Next Day Moulding,</b> <i>Boston's Moulding Super Store!</i>
			<span id = "Next-day"><i class="fa fa-copyright"></i>

            2017 Next Day Moulding. All rights Reserved.</span></p>
		</div>
        <div class="content">
		<ul class="nav justify-content-end">
				<li class="nav-item"><a class="nav-link text-dark" href="#">Return Policy    |</a></li>
				<li class="nav-item"><a class="nav-link text-dark" href="#">Terms of Service    |</a></li>
				<li class="nav-item"><a class="nav-link text-dark" href="#">Privacy Policy</a></li>
			</ul>
		</div>
	</footer>
</body>
</html>

