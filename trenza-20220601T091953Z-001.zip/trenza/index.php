
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Next Day Moulding</title>	
	<!-- bootstrap link  -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

	<!-- icon-link   -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<!-- slick css  -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" integrity="sha512-yHknP1/AwR+yx26cB1y0cjvQUMvEa2PFzt1c9LlS4pRQ5NOTZFWbhBig+X9G9eYW/8m0/4OXNx8pxJ6z57x0dw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	
	<!-- meanmenu  -->
	<link rel="stylesheet" href="meanmenu.css" media="all" />
	
	<!-- css link  -->
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="ipad-land.css">
	<link rel="stylesheet" href="ipad-port.css">
	<link rel="stylesheet" href="iphone-land.css">
	<link rel="stylesheet" href="iphone-land2.css">
	<link rel="stylesheet" href="iphone-port.css">
</head>
<body>
	<section class="content">
		<section>
			<ul class="nav justify-content-end">
				<li class="nav-item"><a class="nav-link text-dark" href="#"><b>Welcome, Jordan</b></a></li>
				<li class="nav-item"><a class="nav-link text-dark" href="#">My Account <i class="fa fa-caret-down"></i></a></li>
				<li class="nav-item">
					<a class="nav-link text-dark" href="#">My List</a>
				</li>
			</ul>
		</section>
		<section class ="display-flex"> 
			<!-- logo  -->
				<a href="index.php"><img class= "logo" src="images/Logo.png" alt="" srcset=""></a>
			<!-- search-bar  -->
			<div class="search-bar">
				<span class = "all">All <i class="fa fa-caret-down"></i></span>
				<input class = "search-input"  type="text" placeholder="Search"> <i class="fa fa-search"></i>
			</div>
			<!-- Questions and Phone  -->
			<div class="call">
				<a class="nav-link " href="#">Questions?<br>Call 781.843.6666</a>
			</div>
			
			<div class="cart"> <span id = "cart">Cart</span>| 8 Items/$1,042.00 				
			</div>
			<div class ="shopping-card">
			    <img src="images/shopping-card.png" alt="" srcset="">
			</div>
		</section>
<!-- navbar  -->
	<section>	
			<nav>
				<ul>
					<li>
						<a  href="#"><img src="images/home-icon.png" alt="" srcset=""></a>
						<div class = "menu-icon">
						</div>
					</li>
					<span>|</span>
					<li class=" dropdown1"><a href="#">MOULDINGS & BOARDS</a>
					<div class = "menu-icon">
						</div> 
						<ul class="dropdown">
							<li><a href="#">link 0</a></li> 
							<li><a href="#">Link 1</a></li>
							<li><a href="#">Link 2</a></li>
							<li><a href="#">Link 3</a></li>
							<li><a href="#">Link 1</a></li>
							<li><a href="#">Link 2</a></li>
							<li><a href="#">Link 3</a></li>
						</ul> 
					</li>
					<span>|</span>
					<li><a href="#">STAIR PARTS</a></li>
					<div class = "menu-icon">
						</div>
					<span>|</span>
					<li><a href="#">ACCENTS</a></li>
					<div class = "menu-icon">
						</div>
					<span>|</span>
					<li>
						<a  href="#">CUSTOM MOULDINGS</a>
						<div class = "menu-icon">
						</div>
					</li>
					<span>|</span>
					<li >
						<a  href="#">CONTACT</a>
						<div class = "menu-icon">
						</div>
					</li>
				</ul>
			</nav>
		</section>

</section>
	<main>

		<!-- slider  
		<section class="slick">
             <div>
				<img src="images/Slider-Image.png" alt="" srcset="">
					<div class="text-block">
						<h4>Mouldings & Boards</h4>
						<button class = "ms-auto">SHOP NOW</button>
					</div>
			 </div>
			 <div >
				<img src="images/Slider-Image.png" alt="" srcset="">
			 </div>
			 <div >
				<img src="images/Slider-Image.png" alt="" srcset="">
			 </div>
		</section>-->
		<section class="slider-section mt-5">
			<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
			<div class="carousel-indicators">
				<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
				<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
				<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
			</div>
			<div class="carousel-inner">
				<div class="carousel-item active">
					<img src="images/Slider-Image.png" class="d-block w-100" alt="...">
					<div class="carousel-caption  d-md-block slider-text-block">
						<p id = "slider-text-p1">Boston's Moulding Super Store!</p>
						<img src="images/yollow-line.png" alt="" srcset="">
						<hr>	
						<h1>Convenience</h1>
						<p>Boston metro-area orders placed <br>
						before 3 p.m. deliver next day!
						</p>
					</div>
				</div>
				<div class="carousel-item">
					<img src="images/Slider-Image.png" class="d-block w-100" alt="...">
					<div class="carousel-caption  d-md-block slider-text-block">
				      <p id = "slider-text-p1">Boston's Moulding Super Store!</p>
						<img src="images/yollow-line.png" alt="" srcset="">
						<hr>	
						<h1>Convenience</h1>
						<p>Boston metro-area orders placed <br>
						before 3 p.m. deliver next day!
						</p>
					</div>
				</div>
				<div class="carousel-item">
					<img src="images/Slider-Image.png" class="d-block w-100" alt="...">
					<div class="carousel-caption d-md-block slider-text-block">
						<p id = "slider-text-p1">Boston's Moulding Super Store!</p>
						<img src="images/yollow-line.png" alt="" srcset="">
						<hr>	
						<h1>Convenience</h1>
						<p>Boston metro-area orders placed <br>
						before 3 p.m. deliver next day!
						</p>
					</div>
				</div>
			</div>
			<button class="carousel-control-prev " type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="visually-hidden">Previous</span>
			</button>
			<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="visually-hidden">Next</span>
			</button>
			</div>
		</section>
		<!-- Purchase products  -->
		<section class ="Purchase-color">
			<div class ="content display-flex" >
				<div class="Purchase ">
					<p><img src="images/arrow-side.png" alt="" srcset=""> Purchase products today, FREE Next Day Moulding delivery tomorrow!</p>
				</div>
				<div class ="Bilder">
					<p><img src="images/arrow-side.png" alt="" srcset=""> Bilder/Contractor Services</p>
				</div>
			</div>
		</section>
		<section class="content">
			<div class = "row pt-3">
				<div class = "col-md-4">
					<img src="images/picture1.png" alt="" srcset="">
					<div class="text-block">
						<h4>Mouldings & Boards</h4>
						<button class = "ms-auto">SHOP NOW</button>
					</div>
				</div>
				<div  class = "col-md-4">
					<img src="images/Picture2.png" alt="" srcset="">
					<div class="text-block">
						<h4>Stair Parts</h4>
						<button class = "ms-auto">SHOP NOW</button>
					</div>
				</div>
				<div  class = "col-md-4">
					<img src="images/picture3.png" alt="" srcset="">
					<div class="text-block">
						<div><h4>Accents</h4></div>
						<button class = "ms-auto">SHOP NOW</button>
					</div>
				</div>
			</div>
		</section>

		<section class="content">
			<div class = "text-shop-view">
				<h2><b>Shop Mouldings & Boards</b> </h2>
				<p><b>view all mouldings & boards products</b></p>
			</div>
			<img src="images/yollow-line.png" alt="" srcset="">
		</section>
<!-- product view card  -->
		<section class="content">
<!-- row 1  -->
			<div class="row slider-row1">
				<!-- row 1 col 1  -->
				<div class="col">
					<div class="card">
						<img src="images/first-col-image1.png" alt=" ">
						<h3><b>Architrave 5010</b></h3>
						<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
						<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
						<p><button><span class = "plus">+</span>Select Option</button></p>
						<div class = "new-sale">
							<img src="images/new(1).png" alt="" srcset="">
						</div>
					</div>
				</div>
				<!-- row 1 col 2  -->
				<div class="col">
					<div class="card">
						<img src="images/first-col-img2.png" alt=" ">
						<h3><b>Architrave 5010</b></h3>
						<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
						<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
						<p><button><span class = "plus">+</span>Select Option</button></p>
					</div>
			  	 </div>
				<!-- row 1 col 3  -->		
				<div class="col">
					<div class="card">
						<img src="images/first-col-img3.png" alt=" ">
						<h3><b>Architrave 5010</b></h3>
						<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
						<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
						<p><button><span class = "plus">+</span>Select Option</button></p>
						<div class = "new-sale">
							<img src="images/sale(1).png" alt="" srcset="">
						</div>
					</div>
				</div>
				<!-- row 1 col 4  -->
				<div class="col">
					<div class="card">
						<img src="images/first-col-img4.png" alt=" ">
						<h3><b>Architrave 5010</b></h3>
						<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
						<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
						<p><button><span class = "plus">+</span>Select Option</button></p>
					</div>
				</div>
				<!-- row 1 col 5  -->
				<div class="col">
					<div class="card">
						<img src="images/first-col-img5.png" alt=" ">
						<h3><b>Architrave 5010</b></h3>
						<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
						<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
						<p><button><span class = "plus">+</span>Select Option</button></p>
					</div>
				</div>
		    </div>
		</section>
		<section class="content">
			<div class = "text-shop-view mt-1">
				<h2><b>Shop Mouldings & Boards</b> </h2>
				<p><b>view all mouldings & boards products</b></p>
			</div>
				<img src="images/yollow-line.png" alt="" srcset="">
		</section>
        <section class="content">
<!-- row 2  -->			
			<div class="row slider-row1">
			<!-- row 2 col 1  -->
			    <div class="col">
					<div class="card">
						<img src="images/second-col-img1.png" alt=" ">
						<h3><b>Architrave 5010</b></h3>
						<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
						<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
						<p><button><span class = "plus">+</span>Select Option</button></p>
						<div class="new-sale">
							<img src="images/new(1).png" alt="" srcset="">
						</div>
					</div>
				</div>
				<!-- row 2 col 2  -->
				<div class="col">
					<div class="card card-height">
						<img src="images/second-col-img2.png" alt=" ">
						<h3><b>Architrave 5010</b></h3>
						<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
						<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
						<p><button><span class = "plus">+</span>Select Option</button></p>
					</div>
			   	</div>
				<!-- row 2 col 3  -->
				<div class="col">
					<div class="card">
						<img src="images/second-col-img3.png" alt=" ">
						<h3><b>Architrave 5010</b></h3>
						<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
						<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
						<p><button><span class = "plus">+</span>Select Option</button></p>
						<div class="new-sale">
							<img src="images/sale(1).png" alt="" srcset="">	
						</div>
					</div>
				</div>
				<!-- row 2 col 4  -->
				<div class="col">
					<div class="card card-height">
						<img src="images/second-col-img4.png" alt=" ">
						<h3><b>Architrave 5010</b></h3>
						<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
						<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
						<p><button><span class = "plus">+</span>Select Option</button></p>
					</div>
				</div>
				<!-- row 2 col 5  -->
				<div class="col">
					<div class="card">
						<img src="images/second-col-img5.png" alt=" ">
						<h3><b>Architrave 5010</b></h3>
						<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
						<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
						<p><button><span class = "plus">+</span>Select Option</button></p>
					</div>
				</div>
			</div>
		</section>
		<section class="content">
			<div class = "text-shop-view mt-1">
				<h2><b>Shop Mouldings & Boards</b> </h2>
				<p><b>view all mouldings & boards products</b></p>
			</div>
				<img src="images/yollow-line.png" alt="" srcset="">
		</section>
		<section class="content">
<!-- row 3  -->
			<div class="row slider-row1">
				<!-- row 3 col 1  -->
				<div class="col">
					<div class="card">
						<img src="images/third-col-img1.png" alt=" ">
						<h3><b>Architrave 5010</b></h3>
						<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
						<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
						<p><button><span class = "plus">+</span>Select Option</button></p>
						<div class="new-sale">
							<img src="images/new(1).png" alt="" srcset="">
						</div>
					</div>
				</div>
					<!-- row 3 col 2  -->
				<div class="col">
					<div class="card">
						<img src="images/third-col-img2.png" alt=" ">
						<h3><b>Architrave 5010</b></h3>
						<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
						<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
						<p><button><span class = "plus">+</span>Select Option</button></p>
				    </div>
				</div>
					<!-- row 3 col 3  -->
				<div class="col">
					<div class="card">
						<img src="images/third-col-img3.png" alt=" ">
						<h3><b>Architrave 5010</b></h3>
						<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
						<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
						<p><button><span class = "plus">+</span>Select Option</button></p>
						<div class="new-sale">
							<img src="images/sale(1).png" alt="" srcset="">
						</div>
					</div>
				</div>
					<!-- row 3 col 4  -->
				<div class="col">
					<div class="card">
						<img src="images/third-col-img4.png" alt=" ">
						<h3><b>Architrave 5010</b></h3>
						<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
						<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
						<p><button><span class = "plus">+</span>Select Option</button></p>
					</div>
				</div>
					<!-- row 3 col 5  -->
				<div class="col">
					<div class="card">
						<img src="images/third-col-img5.png" alt=" ">
						<h3><b>Architrave 5010</b></h3>
						<p class="price">1-1/8"<span>&#10799;</span>4-1/4"</p>
						<p class="price-text">From <span class ="dollar">$</span><span class = "dollar-number">1.47</span>/linear foot</p>
						<p><button><span class = "plus">+</span>Select Option</button></p>
					</div>
				</div>	
			</div>
		</section>
	</main>
	<br>
	<br>


<!-- FOOTER  -->
	<footer>
	<div class="content">
		<div class="row footer-section1">
			<div class="col">
				<img src="images/Logo.png" alt="" srcset="">
			</div>
			<div class="col">
				<div class="row">
					<div class="col-1">
						<img src="images/call-icon.png" alt="" srcset="">
					</div>
					<div class="col-9">				
						<a class="nav-link pt-0 phone" href="#">781.843.6666</a>
						<a class="nav-link pt-0 phone pb-2" href="email">info@ndmoulding.com</a>
					</div>
				</div>
			</div>
			<div class="col">
				<div class="row">
					<div class="col-2">
						<img src="images/home-icon.png" alt="" srcset="">
					</div>
					<div class="col-10">
						<h5>236 Wood Rd.</h5>
						<h6>Braintree, MA 02184</h6>
					</div>
				</div>
			</div>
			<div class="col">
				<div class="row">
					<div class="col-2">
						<img src="images/home-icon.png" alt="" srcset="">
					</div>
					<div class="col-10">
						<h5>10 industrial Pkwy</h5>
						<h6>Woburn, MA 01801</h6>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="row">
					<div class="col-2">
						<img src="images/clock-icon.png" alt="" srcset="">
					</div>
					<div class="col-10">
						<h5>Mon - Fri, 7 a.m. -6 p.m.</h5>
						<h5>Sat, 7 a.m. -2 p.m.</h5>
					</div>
				</div>
			</div>
		</div>
	</div>
		<div id = footer-section2>
			<p class="content"><b>Next Day Moulding,</b> <i>Boston's Moulding Super Store!</i>
			<span id = "Next-day"><i class="fa fa-copyright"></i>

            2017 Next Day Moulding. All rights Reserved.</span></p>
		</div>
        <div class="content">
		<ul class="nav justify-content-end">
				<li class="nav-item"><a class="nav-link text-dark" href="#">Return Policy    |</a></li>
				<li class="nav-item"><a class="nav-link text-dark" href="#">Terms of Service    |</a></li>
				<li class="nav-item"><a class="nav-link text-dark" href="#">Privacy Policy</a></li>
			</ul>
		</div>
	</footer>


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js" integrity="sha512-XtmMtDEcNz2j7ekrtHvOVR4iwwaD6o/FUJe6+Zq+HgcCsk3kj4uSQQR8weQ2QVj1o0Pk6PwYLohm206ZzNfubg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	<script type = "text/javascript"> 
		$('.slick').slick({
		dots: false,
		infinite: true,
		speed: 300,
		slidesToShow: 1,
		adaptiveHeight: true,
		arrows: true,
		});
	</script>
	<Script type = "text/javascript">
		$('.slider-row1').slick({
  	dots: false,
	infinite: true,
	arrows:true,
	speed: 300,
	slidesToShow: 4,
	slidesToScroll: 1,
	responsive: [
    {
      breakpoint: 1050,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: true,
        dots:false
      }
    },
    {
      breakpoint: 810,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
	</Script>

<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="jquery.meanmenu.js"></script>
<script>
	jQuery(document).ready(function () {
	    jQuery('section nav').meanmenu();
	});
</script>

</body>
</html>

