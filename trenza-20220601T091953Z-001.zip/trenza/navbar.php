<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script>
        $(document).ready(function(){
            $('#icon').click(function(){
                $('ul').toggleClass('show');
            });
        });
    </script>
<style>
    *{
        padding: 0;
        margin: 0;
        text-decoration: none;
        list-style: none;
    }
  nav{
      height: 80px;
      width: 100%;
      background: #34495e;
  }
  label.logo{
      font-size: 35px;
      font-weight: bold;
      color: white;
      padding: 0 100px;
      line-height: 80px;
  }
  nav ul{
      float: right;
      margin-right: 40px;
  }
  nav li{
      display: inline-block;
      margin: 0 80px;
      line-height: 80px;
  }
 nav a{
     color: white;
     font-size: 18px;
     text-transform: uppercase;
     border: 1px solid transparent;
     padding: 7px 10px;
     border-radius: 3px;
 }
 a.active,a:hover{
     border: 1px solid white;
     transition: .5s;
 }
 nav #icon{
     color: white;
     font-size: 30px;
     line-height: 80px;
     float:right;
     margin-right: 40px;
     cursor: pointer;
     display: none;
 }
 @media (max-width:1050px){
     label.logo{
         font-size: 32px;
         padding-left: 60px;
     }
     nav ul{
         margin-right: 20px;
     }
     nav a{
         font-size: 17px;
     }
 }
 @media (max-width:1050px){
    nav #icon{
        display: block;
    }
    nav ul{
        position: fixed;
        width: 100%;
        height:100vh;
        background: #2f3640;
        top:80px;
        left:-100%;
        text-align: center;
        transition: all .5s;
    }
    nav li{
        display: block;
        margin: 50px 0;
        line-height: 30px;
    }
    nav a{
        font-size: 20px;
    }
    a.active,a:hover{
        border:none;
        color:#3498db;
    }
    nav ul.show{
        left: 0;
    }

 }
</style>

</head>
<body>
    <nav>
        <label class="logo">Desing</label>    
        <ul>
            <li><a class = "active" href="#">home-1</a></li>
            <li><a href="#">home-2</a></li>
            <li><a href="#">home-3</a></li>
            <li><a href="#">home-4</a></li>
            <li><a href="#">home-5</a></li>
        </ul>
        <label id="icon">
            <i class="fas fa-bars"></i>
        </label>
    </nav>
</body>
</html>